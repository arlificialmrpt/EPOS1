<?php

namespace App\Http\Controllers;
use Illuminate\Foundation\Http\Middleware\TransformsRequest;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\AppUsers;
use DB;
class AppUsersController extends Controller
{

public function AppLoginLogin(Request $req)
    {
 		$LoginVerification = DB::select('SELECT  [AppLogin_Email] ,[AppLogin_Password], [AppLogin_Status]
		FROM [AppLogins] where  [AppLogin_Email]=? ',[$req->input('AppLogin_Email')]);

            if (!empty($LoginVerification[0]->AppLogin_Email))
            {
            	
	          	if ($LoginVerification[0]->AppLogin_Status == 1)
				{ 


						if ((Hash::check($req->input('AppLogin_Password'), $LoginVerification[0]->AppLogin_Password))) 
						{
					    // The passwords match...
							 return "User Login Succesfuly" ;
						}
						else
						{
					    return "User or Password not found" ;

						}
				}
				else 
				{
					return "Accout is disabled" ;
				}
			}
			else
			 {

  			 return "User is not registered" ;

			}
		}


     public function SaveAppUser(Request $req)
       {
      //return $req->input('AppLogin_Email');
			$AppLogin = DB::select('SELECT [AppLogin_Email] FROM [AppLogin] where [AppLogin_Email] =?',[$req->input('AppLogin_Email')]);
          if (!empty($AppLogin->AppLogin_Email))
          {
          	$AppLogin_Save= new AppUsers();
			$AppLogin_Save->AppLogin_Email= $req->input('AppLogin_Email');
		    $AppLogin_Save->AppLogin_User_Name= $req->input('AppLogin_User_Name');
		    // $AppLogin_Save->AppLogin_Ph_No= $req->input('AppLogin_Ph_No');
		    $AppLogin_Save->AppLogin_Password= Hash::make($req->input('AppLogin_Password'));
		    $AppLogin_Save->AppLogin_Status= '1';
			$AppLogin_Save->save();
			return "Inserted Succesfuly" ;
          }
          else{

          return "User Already regestered " ;

          }
 
        
    }
     public function UpdateAppLogin(Request $req)
    {
    	 
         $affected = DB::table('AppLogins')

              ->where('AppLogin_Email', $req->input('AppLogin_Email'))
              ->update(['AppLogin_Email' => $req->input('AppLogin_Email'),
                        'AppLogin_Full_Name' => $req->input('AppLogin_Full_Name'),
                        'AppLogin_Ph_No' => $req->input('AppLogin_Ph_No')]);
    }
   public function UpdateAppLoginPassowrd(Request $req)
    {
    	 
    }
     public function GetClient(Request $req)
    {
  
         $Items = DB::select('SELECT  * FROM [AppLogin] where Client_ID  =?',[$req->Client_ID]);
      
        return json_encode($Items);
    }
}
