<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use DateTime;
class OrderController extends Controller
{
      


     public function SaveOrder(Request $req)
       {
      $today_Date = new DateTime();

$Order = DB::select('SELECT  MAX(Order_ID), MAX(Order_ID) FROM [Order] where  Order_ID Like=?',$today_Date->format('ymd').'%');
   return $Order;
      
      $Order_save = new Order();
      $Order_save->Order_ID = $req->input('Order_ID');
      $Order_save->Order_Display_ID = $req->input('Order_Display_ID');
      // $Order_save->Cart_ID = $req->input('Cart_ID');
      // $Order_save->Cust_ID = $req->input('Cust_ID');
      $Order_save->Client_ID = $req->input('Client_ID');
      // $Order_save->Emp_ID = $req->input('Emp_ID');
      $Order_save->Order_Source = $req->input('Order_Source');
      $Order_save->Order_Type = $req->input('Order_Type');
      $Order_save->Order_Count = $req->input('Order_Count');
      $Order_save->Order_NetPrice = $req->input('Order_NetPrice');
      $Order_save->Order_Delivery_Charges = $req->input('Order_Delivery_Charges');
      $Order_save->Order_Discount = $req->input('Order_Discount');
      $Order_save->Order_Gross_Total = $req->input('Order_Gross_Total');
      $Order_save->Order_Status = $req->input('Order_Status');
      // $Order_save->Order_Decline_Subject = $req->input('Order_Decline_Subject');
      // $Order_save->Order_Decline_Reason = $req->input('Order_Decline_Reason');
      $Order_save->Order_Payment = $req->input('Order_Payment');
      $Order_save->Order_Phone_Number = $req->input('Order_Phone_Number');
      $Order_save->Order_Post_Code = $req->input('Order_Post_Code');
      $Order_save->Order_Door_Number = $req->input('Order_Door_Number');
      $Order_save->Order_Town = $req->input('Order_Town');
      $Order_save->Order_Street = $req->input('Order_Street');
      // $Order_save->Transaction_Id = $req->input('Transaction_Id');
      $Order_save->Order_Client_Full_Name = $req->input('Order_Client_Full_Name');
      $Order_save->Order_Placing_Time = $req->input('Order_Placing_Time');
      $Order_save->Order_Completion_Time = $req->input('Order_Completion_Time');
      // $Order_save->Order_Updating_Time = $req->input('Order_Updating_Time');
      

      $Order_save->save();
      
        return "Inserted Succesfuly" ;
    }



     public function UpdateOrder(Request $req)
       {
        try {


          
         $affected = DB::table('Order')

              ->where('Order_ID', $req->input('Order_ID'))
              ->update(['Order_Count' => $req->input('Order_Count'),
                        'Order_NetPrice' => $req->input('Order_NetPrice'),
                        'Order_Delivery_Charges' => $req->input('Order_Delivery_Charges'),
                        'Order_Discount' => $req->input('Order_Discount'),
                        'Order_Gross_Total' => $req->input('Order_Gross_Total'),
                        'Order_Status' => $req->input('Order_Status'),
                        'Order_Payment' => $req->input('Order_Payment'),
                        'Order_Phone_Number' => $req->input('Order_Phone_Number'),
                        'Order_Post_Code' => $req->input('Order_Post_Code'),
                        'Order_Door_Number' => $req->input('Order_Door_Number'),
                        'Order_Town' => $req->input('Order_Town'),
                        'Order_Street' => $req->input('Order_Street'),
                        'Transaction_Id' => $req->input('Transaction_Id'),
                        'Order_Client_Full_Name' => $req->input('Order_Client_Full_Name'),
                        'Order_Placing_Time' => $req->input('Order_Placing_Time'),
                        'Order_Post_Code' => $req->input('Order_Post_Code'),
                        'Order_Door_Number' => $req->input('Order_Door_Number'),
                        'Order_Completion_Time' => $req->input('Order_Completion_Time'),
                        'Order_Updating_Time' => $req->input('Order_Updating_Time')
                    


            ]);
            return $affected;  
        }
   }
catch(Exception $e){

  echo 'Caught exception: ',  $e->getMessage(), "\n";
}
    
      
        return "Inserted Succesfuly" ;
    }


       public function GetOrderDetails(Request $req)
        {
          try {

            $OrderDetails = DB::select('SELECT  *  from [Order_Items] where [Order_ID] =? ',[$req->input('Order_ID')]);
            for ($i=0; $i <$OrderDetails.count(rows) ; $i++) { 
              # code...
            }
         }
          catch(Exception $e){
 
                  echo 'Caught exception: ',  $e->getMessage(), "\n";
                }
   }
}
