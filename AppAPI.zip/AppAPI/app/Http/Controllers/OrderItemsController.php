<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OrderItemsController extends Controller
{
     public function UpdateOrderItem(Request $req)
    {

                  //$req= json_encode($req->all());
                 
          // $indicater[Order_ID]  = $req->input('Order_ID');
      // $indicater['Cat_ID']  = $req->input('Cat_ID');
       // $indicater[DealCart_ID]  = $req->input('Order_ID');
      // $indicater[Item_ID] = $req->input('Order_ID');
       $indicater['Item_Name'] = $req->input('Order_ID');
       $indicater['ECItem_UnitPrice'] = $req->input('Order_ID');
       $indicater['Is_Deal'] = $req->input('Order_ID');
       $indicater['ECItem_Qty'] = $req->input('Order_ID');
       $indicater['ECItem_Discount'] = json_encode($req->input('Order_ID'));
       $indicater['ECItem_DiscFlag'] = $req->input('Order_ID');
       $indicater['ECItem_PlusTotalQty'] = $req->input('Order_ID');
       $indicater['ECItem_Plus_Flag'] = $req->input('Order_ID');
      $indicater['Item_NetPrice']  = $req->input('Order_ID');
      $indicater['OrdeItem_Status'] = $req->input('Order_ID');
      for ($i=0; $i <$req->input('ECItem_PlusTotalQty') ; $i++) { 
          $indicater['ECItem_Plus'.$i.'_Name'] =$req->input('ECItem_Plus'.$i.'_Name');
          $indicater['ECItem_Plus'.$i.'_Price'] =$req->input('ECItem_Plus'.$i.'_Price');
          $indicater['ECItem_Plus'.$i.'_Qty'] =$req->input('ECItem_Plus'.$i.'_Qty');
          $indicater['ECItem_Plus'.$i.'_Type'] =$req->input('ECItem_Plus'.$i.'_Type');
       
      }
      $affected = DB::table('users')
              ->where('Order_ID', $req->input('Order_ID'))
              ->update($indicater);
              return $affected;

    }

}
