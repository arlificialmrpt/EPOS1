<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;

class ItemsController extends Controller
{
    
    public function GetSpecificItems(Request $req)
    {
  
         $Items = DB::select('SELECT  * FROM [Items] where Cat_ID  =?',[$req->Cat_ID]);
      
        return json_encode($Items);
    }
    public function GetAllItems(Request $req)
    {
  
         $Items = DB::select('SELECT  * FROM [Items]');
      
        return json_encode($Items);
    }
}
