<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function GetSpecificCategories(Request $req)
    {
  
         $Categories = DB::select('SELECT  * FROM [Categories] where Cat_ID  =?',[$req->Cat_ID]);
      
        return json_encode($Categories);
    }
    public function GetAllCategories(Request $req)
    {
  
         $Categories = DB::select('SELECT  * FROM [Categories]');
      
        return json_encode($Categories);
    }

     public function GetFirstLevelCategories()
    {
         $Categories = DB::select('SELECT * FROM [Categories] where Cat_Level=1 AND Cat_Status=1');
      
        return json_encode($Categories)  ;
    }}
