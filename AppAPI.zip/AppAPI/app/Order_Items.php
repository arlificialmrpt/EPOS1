<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order_Items extends Model
{
   public $timestamps = false;
      protected $table  = 'Order_Items';
}
