<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
						/*AppLogin*/
						/*AppClient*/
						
Route::post('SaveAppUser', 'AppUsersController@SaveAppUser');

Route::get('AppUserLogin', 'AppUsersController@AppUserLogin');
						/*Category*/

Route::get('GetFirstLevelCat', 'HomeController@GetFirstLevelCat');
Route::get('GetAllCategories', 'HomeController@GetAllCategories');
Route::get('GetSpecificCategories', 'HomeController@GetSpecificCategories');	

						/*Item*/
Route::get('GetSpecificItems', 'HomeController@GetSpecificItems');
Route::get('GetAllItems', 'ItemsController@GetAllItems');

						/*Order*/
Route::post('UpdateOder', 'OrderController@UpdateOder');
Route::post('SaveOrder', 'OrderController@SaveOrder');

						/*OrderItems*/
Route::post('SaveOrderItem', 'HomeController@SaveOrderItem');
Route::post('UpdateOrderItem', 'HomeController@UpdateOrderItem');	


Route::get('GetOrderDetails', 'OrderController@GetOrderDetails');
					
						/*Deal*/
						/*Timing*/
						/*OrderType*/




